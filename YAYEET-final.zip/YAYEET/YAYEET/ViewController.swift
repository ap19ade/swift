//
//  ViewController.swift
//  YAYEET
//
//  Created by ap19ade on 14/01/2020.
//  Copyright © 2020 ap19ade. All rights reserved.
//

//imports
import UIKit
import SpriteKit
import AVFoundation

//protocol declaration
protocol getBall {
    func ball()
}

class ViewController: UIViewController, getBall, UICollisionBehaviorDelegate{
    
    
    //declaration of variables
    var setTimer = 30
    var timer = Timer()
    var audioPlayer =  AVAudioPlayer()
    var dynamicAnimator: UIDynamicAnimator!
    var dynamicItemBehaviour: UIDynamicItemBehavior!
    var gravityBehaviour: UIGravityBehavior!
    var collisionBehaviour: UICollisionBehavior!
    var dynamicAnimator2: UIDynamicAnimator!
    var dynamicItemBehaviour2: UIDynamicItemBehavior!
    var gravityBehaviour2: UIGravityBehavior!
    var collisionBehaviour2: UICollisionBehavior!
    
    @IBOutlet weak var cage: UIView!
    @IBOutlet var timerLabel: UILabel!
    @IBOutlet weak var aim: DragImageView!
    
    //timer countdown
    @objc func countdown(){
         timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.count), userInfo: nil, repeats: true)
        setTimer = 15
        timerLabel.text = String(setTimer)
    }
    
    @objc func count() {//countdown timer
        setTimer -= 1
        timerLabel.text = String(setTimer)
        
        //if timer = 0
        if setTimer == 0 {
            timer.invalidate()
            Timer.scheduledTimer(timeInterval: 0, target: self, selector: #selector(ViewController.end), userInfo: nil, repeats: false)
        }
    }
    
    @objc func end(){ //to switch to end game
       
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "endGame") as! EndViewController
        
        self.present(vc, animated: false, completion: nil)
        
    }
    

    //Attempt of sound effects for game 
    @IBAction func sounds(_ sender: UIImageView){
        let sound = sender.tag
        
        let pathToSound = Bundle.main.path(forResource: "musica_1", ofType: "mp3")!
        let url = URL(fileURLWithPath: pathToSound)
        
        
        do{
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer.play()
        } catch {
            //error handling
        }
        
        switch sound {
        case 5:
            let pathToSound = Bundle.main.path(forResource: "yeet_N3RSTZe", ofType: "mp3")!
            let url = URL(fileURLWithPath: pathToSound)
            
            do{
                audioPlayer = try AVAudioPlayer(contentsOf: url)
                audioPlayer.play()
            } catch {
                //error handling
            }
            
        default:
            return
        }
    }
    
    
    func bird(){//funcion to get birds
        let randomMax = Int.random(in: 2..<12)
        for n in 1...randomMax {
            let birdName = "bird\(n).png"
            let birdImage = UIImage(named: birdName)
            let bird = UIImageView(image: birdImage!)
            let randomX = Int.random(in: 8..<163)
            let randomY = Int.random(in: 0..<266)
            bird.frame = CGRect(x: randomX, y: randomY, width: 62, height: 56)
            cage.addSubview(bird)
        }
        
        
     
       
        gravityBehaviour2 = UIGravityBehavior(items: [cage])
        
        dynamicAnimator2 = UIDynamicAnimator(referenceView: self.view)
        dynamicItemBehaviour2 = UIDynamicItemBehavior(items:[cage])
        
        //collision behav
        collisionBehaviour2 = UICollisionBehavior(items: [cage])
        collisionBehaviour2.translatesReferenceBoundsIntoBoundary = true
        dynamicAnimator2.addBehavior(collisionBehaviour2)
        
        //animator
        dynamicAnimator2.addBehavior(dynamicItemBehaviour2)
        
        
    }
    func ball(){ //function for ball
        //Image creation
        let ballView = UIImageView(image: nil)
        
        //assign image
        ballView.image = UIImage(named: "ball.png")
        
        //transform ball to Sprite
        let Texture = SKTexture(imageNamed: "ball.png")
        let Sprite2 = SKSpriteNode(texture: Texture)
        Sprite2.physicsBody?.isDynamic = true
        
         ballView.frame = CGRect(x:aim.center.x, y:aim.center.y+100,width:40, height:40)
        
         //add img main view
         self.view.addSubview(ballView)
        
        
        
        
        // Do any additional setup after loading the view.
        
        dynamicAnimator = UIDynamicAnimator(referenceView: self.view)
        dynamicItemBehaviour = UIDynamicItemBehavior(items:[ballView])
        gravityBehaviour = UIGravityBehavior(items: [ballView])
        
        
//        let width = UIScreen.mainScreen().bounds.size.width - 50
//        let height = UIScreen.mainScreen().bounds.size.height - 50
//        let borderBody = SKPhysicsBody(edgeLoopFromRect: CGRect(x: 20, y: -90, width: width, height: height))\
        
        //liner and angular velocity
        
        self.dynamicItemBehaviour.addLinearVelocity(CGPoint(x:1000, y:1000), for: ballView)
        self.dynamicItemBehaviour.addAngularVelocity(100, for: ballView)
        
//        self.collectionView.deleteItemsAtIndexPaths([ballView])
        
        
        //dynamicItemBehaviour = UIDynamicItemBehavior(items:[ballView])
        //dynamicItemBehaviour.elasticity = 0.7
        //dynamicAnimator.addBehavior(dynamicItemBehaviour)

        
        //collision behav

        collisionBehaviour = UICollisionBehavior(items: [ballView])
        collisionBehaviour.translatesReferenceBoundsIntoBoundary = true
        dynamicAnimator.addBehavior(collisionBehaviour)
        
        //animator
        
        dynamicAnimator.addBehavior(dynamicItemBehaviour)
        dynamicAnimator.addBehavior(gravityBehaviour)
//
//        Sprite.position = CGPoint(x:100, y:100)
//        Sprite.setScale(0.1)
//        Sprite.physicsBody?.isDynamic = true
//        Sprite.physicsBody = SKPhysicsBody(circleOfRadius: Sprite.size.width / 2);
//
//        Sprite.physicsBody?.applyImpulse(CGVector(dx: 100, dy: 100))

    
    }
    @IBOutlet var button: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        //call bird func
        bird()
        countdown()
        //make border start button round
        //button.layer.cornerRadius = 5.0
        aim.myDelegate = self
    }


}

