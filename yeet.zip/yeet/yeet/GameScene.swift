//
//  GameScene.swift
//  yeet
//
//  Created by ap19ade on 13/01/2020.
//  Copyright © 2020 ap19ade. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    override func didMove(to view: SKView) {
    }
}
